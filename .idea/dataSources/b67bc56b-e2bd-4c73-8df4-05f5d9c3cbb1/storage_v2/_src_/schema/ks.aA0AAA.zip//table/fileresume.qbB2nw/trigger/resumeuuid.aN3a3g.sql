create definer = root@localhost trigger RESUMEUUID
    before insert
    on fileresume
    for each row
BEGIN
    set new.FFILEID=uuid();
    END;

