create definer = root@localhost trigger COMPANYIMGUUID
    before insert
    on filecompany
    for each row
BEGIN
    SET new.FFILEID=UUID();
    END;

