create definer = root@localhost trigger WEBADVICEUUID
    before insert
    on webadvice
    for each row
BEGIN
    SET new.`WAID`=UUID();
    END;

