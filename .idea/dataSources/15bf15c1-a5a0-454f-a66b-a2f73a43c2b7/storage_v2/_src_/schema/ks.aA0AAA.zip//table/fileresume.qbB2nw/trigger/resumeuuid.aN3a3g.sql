create definer = root@localhost trigger RESUMEUUID
    before insert
    on fileresume
    for each row
BEGIN
    SET new.FFILEID=UUID();
    END;

